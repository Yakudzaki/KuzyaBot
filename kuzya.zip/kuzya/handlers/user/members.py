from loader import dp, bot

from aiogram import types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton



@dp.message_handler(content_types=["new_chat_members"])
async def new_chat_member(message: types.Message):
    chat_id = message.chat.id
    user = message.new_chat_members[0]
    
    if user.id == (await bot.get_me()).id and message.chat.id != -1001499340172:
        await message.answer("❌ Я создан исключительно для чата <a href='https://t.me/+G-B1jix_0g5lMmQy'>Опа Это Топа</a>!", parse_mode="html", disable_web_page_preview=True)
        return
        await bot.leave_chat(message.chat.id)
    
    hello = InlineKeyboardMarkup(row_width=1,
    inline_keyboard=[
        [
            InlineKeyboardButton(text='📝 Правила', url="https://t.me/c/1499340172/2255554")
        ],
    ]
)
    if int(message.chat.id) == int(-1001499340172):
        await message.reply(f"Привет, <a href='tg://user?id={user.id}'>{user.first_name}</a>! Рады видеть тебя в нашем чате! Перед началом общения обязательно ознакомься с правилами. Спасибо💘", parse_mode='html', reply_markup=hello)
    


@dp.message_handler(content_types=["left_chat_member"])
async def left_member(message: types.Message):
    await message.reply(f'Пока, <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a>!😔', parse_mode='html') 