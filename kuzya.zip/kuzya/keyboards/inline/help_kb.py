from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton



buttons = InlineKeyboardMarkup(row_width=1,
    inline_keyboard=[
        [
            InlineKeyboardButton(text='💡 Основное', callback_data='osnova'),
            InlineKeyboardButton(text='👾 Триггеры', callback_data='funny')
        ],
        [
            InlineKeyboardButton(text='👮 Модерация', callback_data='moder')
        ]
    ]
)
