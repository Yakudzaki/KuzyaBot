from .start import dp
from .help import dp
from .meme import dp
from .members import dp
from .admins import dp
from .wiki import dp
from .mute import dp
from .ban import dp
from .warn import dp
from .RP import dp
from .weather import dp
from .audio import dp
from .misc import dp
from .anime import dp
from .joke import dp
from .easters import dp

from .callback import dp


__all__ = ['dp']