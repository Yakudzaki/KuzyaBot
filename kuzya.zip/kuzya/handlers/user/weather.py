from loader import dp, bot
from aiogram import types
import pyowm
from pyowm.utils.config import get_default_config
from datetime import datetime


config_dict = get_default_config()

config_dict['language'] = 'ru' 
owm = pyowm.OWM('4d9c68ba051733b61d30fa2406658670')
mgr = owm.weather_manager()



@dp.message_handler(commands=['погода', 'w', 'weather', 'пагода'], commands_prefix="/!.")
async def send_weather(message):
    try:
        city = message.text.split()[1]
        observation = mgr.weather_at_place(city)
        w = observation.weather
        
        
        text = f"🏙️ <b>Город</b>: <b>{city}</b>\n"
        text += f"🔍 <b>Статус</b> - <em>{w.detailed_status}</em>\n\n"
        text += f"🌡 <b>️Максимальная температура</b>: <code>{w.temperature('celsius')['temp_max']} °C</code>\n"
        text += f"🌡️ <b>Минимальная температура</b>: <code>{w.temperature('celsius')['temp_min']} °C</code>\n"
        text += f"🌡 ️<b>Ощущается как</b>: <code>{w.temperature('celsius')['feels_like']} °C</code>\n\n"
        text += f"💧 <b>Влажность</b>: <code>{w.humidity}%</code>\n"
        text += f"💨 <b>Скорость ветра</b>: <code>{w.wind()['speed']} м/с</code>\n"
        text += f"☁️ <b>Облачность</b>: <code>{w.clouds}%</code>\n"
        
        
        await bot.send_message(message.chat.id, text, parse_mode='HTML')
    except:
        await message.reply("☹ ️Не удалось найти такой город.\nПопробуйте снова.")