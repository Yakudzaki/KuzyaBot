from loader import dp, bot
from aiogram import types
from aiogram.dispatcher.filters import CommandHelp, Text
from loguru import logger
from keyboards.inline.help_kb import buttons
from utils.db.db_utils import *



@dp.message_handler(CommandHelp())
async def help_handler(message: types.Message):
    user = message.from_user
    if check_user(user.id):
        create_user(user.id, user.username, user.first_name)
    await message.answer("<b>📚 Выберите раздел:</b>", reply_markup=buttons)