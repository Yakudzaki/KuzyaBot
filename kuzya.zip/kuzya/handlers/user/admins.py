from loader import dp, bot
from aiogram import types



@dp.message_handler(chat_type=[types.ChatType.SUPERGROUP, types.ChatType.GROUP], commands=['admins', "админы"], commands_prefix='!/.')
async def get_admin_list(message: types.Message):
    admins = await message.chat.get_administrators()
    msg = str("🚨 Админы вызваны!\n\n")
    
    for admin in admins:
        if admin.user.is_bot:
            continue
        msg += f"@{admin.user.username}\n"
    
    if message.reply_to_message:
        id = message.reply_to_message.message_id
        await bot.send_message(message.chat.id, msg, reply_to_message_id=id)