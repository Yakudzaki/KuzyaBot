from loader import dp, bot
from aiogram import types
from wikipedia import (
    WikipediaPage,
    page,
    random,
    search,
    set_lang,
    suggest,
    summary,
)

set_lang("ru")



@dp.message_handler(commands=["wiki", "вики"], commands_prefix="/!.")
async def wiki_handler(message: types.Message):
    request = message.text.replace("/wiki ", "").replace("!wiki ", "").replace("!вики ", "").replace("/вики ", "")
    if request == "/wiki" or request == "!wiki" or request == "!вики" or request == "/вики":
        await message.reply("<b>❌ Укажите запрос!</b>")
        return
    try:
        result = summary(request)
    except:
        await message.reply("☹️ По вашему запросу ничего не найдено!")
        return
    
    await message.reply(f"{result}\n\n🗞 <a href='https://t.me/KuzyaBotNews'>Канал с новостями</a>", disable_web_page_preview=True)



@dp.message_handler(commands=["random", "рандом"], commands_prefix="/!.")
async def randomize(message: types.Message):
    try:
        random_title = page(random(pages=1)).url
        random_text = "🔎 Рандомная статья - <a href='" + random_title + "'>*тык*</a>"
        await message.reply(random_text)
    except IndexError:
        await message.reply("😓 Что-то пошло не так, попробуйте ещё раз!")