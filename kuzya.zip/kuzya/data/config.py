import os
from dotenv import load_dotenv


load_dotenv()


TOKEN = str(os.getenv("BOT_TOKEN"))

server_dir = "/storage/emulated/0/kuzya"

ADMINS = [5548351085]