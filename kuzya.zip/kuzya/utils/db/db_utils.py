import sqlite3


connect = sqlite3.connect("utils/db/kuzya.db")
cursor = connect.cursor()


cursor.execute("""CREATE TABLE IF NOT EXISTS users(
    user_id INTEGER,
    username STRING,
    nick STRING,
    bio STRING,
    gender INTEGER,
    reputation INTEGER,
    warns INTEGER
    )
""")

connect.commit()



def create_user(user_id, username, nick):
    cursor.execute("INSERT INTO users VALUES(?,?,?,?,?,?,?)", (user_id, username, nick, "Нет", 0, 0, 0,))
    connect.commit()



def check_user(user_id):
    cursor.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    result = cursor.fetchone()
    if result is None:
        return True
    else:
        return False



def check_username(username):
    cursor.execute("SELECT * FROM users WHERE username=?", (username,))
    result = cursor.fetchone()
    if result is None:
        return True
    else:
        return False



def get_username(username):
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    user = cursor.fetchone()
    return user



def set_nick(user_id, nick):
    cursor.execute("UPDATE users SET nick = ? WHERE user_id = ?", (nick, user_id,))
    connect.commit()



def set_bio(user_id, bio):
    cursor.execute("UPDATE users SET bio = ? WHERE user_id = ?", (bio, user_id,))
    connect.commit()



def set_gender(user_id, gender):
    cursor.execute("UPDATE users SET gender = ? WHERE user_id = ?", (gender, user_id,))
    connect.commit()



def add_warn(user_id):
    cursor.execute("UPDATE users SET warns = warns + 1 WHERE user_id = ?", (user_id,))
    connect.commit()



def take_warn(user_id):
    cursor.execute("UPDATE users SET warns = warns - 1 WHERE user_id = ?", (user_id,))
    connect.commit()



def add_rep(user_id):
    cursor.execute("UPDATE users SET reputation = reputation + 1 WHERE user_id = ?", (user_id,))
    connect.commit()



def take_rep(user_id):
    cursor.execute("UPDATE users SET reputation = reputation - 1 WHERE user_id = ?", (user_id,))
    connect.commit()



def get_user(id):
    cursor.execute("SELECT * FROM users WHERE user_id = ?", (id,))
    user = cursor.fetchone()
    return user