from loader import dp, bot
from aiogram import types
from aiogram.dispatcher.filters import AdminFilter, IsReplyFilter
import datetime
import time



@dp.message_handler(commands=['ban', 'бан', 'кик', 'kick'], commands_prefix='!?./', is_chat_admin=True)
async def ban(message: types.Message):
   if not message.reply_to_message:
      await message.reply("Эта команда должна быть ответом на сообщение!")
      return
   comment = " ".join(message.text.split()[1:])
   try:
       await bot.kick_chat_member(message.chat.id, message.reply_to_message.from_user.id, types.ChatPermissions(False))
       await message.reply(f'👤Администратор: <a href="tg://?id={message.from_user.id}">{message.from_user.first_name}</a>\n🛑Забанил: <a href="tg://user?id={message.reply_to_message.from_user.id}">{message.reply_to_message.from_user.first_name}</a>\n⏰Срок: навсегда\n📃Причина (если есть): {comment}')
   except:
       await message.reply("Не лучшая идея...")

@dp.message_handler(commands=['разбан', 'unban'], commands_prefix='!?./', is_chat_admin=True)
async def unban(message: types.Message):
   if not message.reply_to_message:
      await message.reply("Эта команда должна быть ответом на сообщение!")
      return
   await bot.restrict_chat_member(message.chat.id, message.reply_to_message.from_user.id, types.ChatPermissions(True, True, True, True))
   await message.reply(f'👤Администратор: <a href="tg://?id={message.from_user.id}">{message.from_user.first_name}</a>\n📲Разбанил: <a href="tg://user?id={message.reply_to_message.from_user.id}">{message.reply_to_message.from_user.first_name}</a>')