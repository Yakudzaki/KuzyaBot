from loader import dp, bot
from keyboards.inline.help_kb import buttons
from aiogram import types



@dp.callback_query_handler(text='funny')
async def funny_help(call: types.CallbackQuery):
    await call.message.edit_text("<b>👾 Триггеры</b>\n\n"
                           "<b>— Поддерживаемые префиксы</b> - <code>/</code>, <code>!</code>, <code>.</code>\n\n"
                           "▷ <code>!рулетка</code> - Сыграть в рулетку (проигрыш = мут на 10 м)\n"
                           "▷ <code>!say</code> or <code>!скажи</code> (текст или ответ на сообщение которое должен сказать бот) - Бот напишет указанный текст\n"
                           "▷ <code>!шутка</code> - Бот отправит шутку :)\n"
                           "▷ <code>!setnick</code> (ник) - Указать ник\n"
                           "▷ <code>!setbio</code> (текст) - Указать био\n"
                           "▷ <code>!setgender</code> (1 или 2) - Указать пол (1 - парень; 2 - девушка)\n"
                           "▷ <code>!рп</code> (действие) - Выполняется действие над юзером, на чье сообщение был сделан ответ с указанным действием\n\n"
                           "▷ <code>Профиль</code> - Показать профиль\n"
                           "▷ <code>Ник</code> - Посмотреть свой ник\n"
                           "▷ <code>Био</code> - Посмотреть своё био\n"
                           "▷ <code>Пол</code> - Узнать свой пол\n\n"
                           "▷ <code>Бот</code> - Проверить работоспособность бота\n"
                           "▷ <code>Кузя</code> (вопрос) - Отвечает на ваш вопрос ответом 'да' или 'нет'\n"
                           "▷ <code>Шанс</code> - показывает вероятность события, указанного в предложении\n", parse_mode="html", reply_markup=buttons)