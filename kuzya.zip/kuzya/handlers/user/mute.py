from loader import dp, bot
from aiogram import types
from aiogram.dispatcher.filters import AdminFilter, IsReplyFilter
from aiogram.types import ChatMemberAdministrator, ChatMemberOwner, ChatPermissions, Message
import datetime
import time



@dp.message_handler(commands=['мут', 'mute'], commands_prefix='!?./', is_chat_admin=True)
async def mute(message: types.Message):
   if not message.reply_to_message:
      await message.reply("Эта команда должна быть ответом на сообщение!")
      return


                                   
   try:
      muteint = int(message.text.split()[1])
      mutetype = message.text.split()[2]
      comment = " ".join(message.text.split()[3:])
   except IndexError:
      await message.reply('Не хватает аргументов!\nПример:\n<code>/мут 1 ч причина</code>')
      return
   try:
           if mutetype == "ч" or mutetype == "часов" or mutetype == "час":
              await bot.restrict_chat_member(message.chat.id, message.reply_to_message.from_user.id, ChatPermissions(False), until_date=datetime.timedelta(hours=muteint))
              await message.reply(f'👤Администратор: <a href="tg://?id={message.from_user.id}">{message.from_user.first_name}</a>\n🔇Замутил: <a href="tg://user?id={message.reply_to_message.from_user.id}">{message.reply_to_message.from_user.first_name}</a>\n⏰Срок: {muteint} {mutetype}\n📃Причина: {comment}')
           if mutetype == "м" or mutetype == "минут" or mutetype == "минуты":
              await bot.restrict_chat_member(message.chat.id, message.reply_to_message.from_user.id, ChatPermissions(False), until_date=datetime.timedelta(minutes=muteint))
              await message.reply(f'👤Администратор: <a href="tg://?id={message.from_user.id}">{message.from_user.first_name}</a>\n🔇Замутил: <a href="tg://user?id={message.reply_to_message.from_user.id}">{message.reply_to_message.from_user.first_name}</a>\n⏰Срок: {muteint} {mutetype}\n📃Причина: {comment}')
           if mutetype == "д" or mutetype == "дней" or mutetype == "день":
              await bot.restrict_chat_member(message.chat.id, message.reply_to_message.from_user.id, ChatPermissions(False), until_date=datetime.timedelta(days=muteint))
              await message.reply(f'👤Администратор: <a href="tg://?id={message.from_user.id}">{message.from_user.first_name}</a>\n🔇Замутил: <a href="tg://user?id={message.reply_to_message.from_user.id}">{message.reply_to_message.from_user.first_name}</a>\n⏰Срок: {muteint} {mutetype}\n📃Причина: {comment}')
   except:
       await message.reply('Не лучшая идея...')



@dp.message_handler(commands=['размут', 'unmute', 'анмут'], commands_prefix='!?./', is_chat_admin=True)
async def unmute(message: types.Message):
   if not message.reply_to_message:
      await message.reply("Эта команда должна быть ответом на сообщение!")
      return
   await bot.restrict_chat_member(message.chat.id, message.reply_to_message.from_user.id, ChatPermissions(True, True, True, True))
   await message.reply(f'👤Администратор: <a href="tg://?id={message.from_user.id}">{message.from_user.first_name}</a>\n🔊Размутил: <a href="tg://user?id={message.reply_to_message.from_user.id}">{message.reply_to_message.from_user.first_name}</a>')