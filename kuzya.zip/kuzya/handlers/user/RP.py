from loader import dp, bot
from aiogram import types
from utils.db.db_utils import *
import re



@dp.message_handler(commands=["рп", "rp"], commands_prefix="/!.")
async def rp_command(message: types.Message):
    if message.reply_to_message:
        if check_user(message.from_user.id):
            create_user(message.from_user.id, message.from_user.username, message.from_user.first_name)
    
        if check_user(message.reply_to_message.from_user.id):
            create_user(message.reply_to_message.from_user.id, message.reply_to_message.from_user.username, message.reply_to_message.from_user.first_name)
        user2 = get_user(message.reply_to_message.from_user.id)
        user = get_user(message.from_user.id)
        action = message.text.lower().replace("/рп ", "").replace(".рп ", "").replace("!рп ", "").replace("!rp", "")
        if action == "":
            await message.reply("<b>❌ Укажи действие</b>!\nПример: !рп Убил")
            return
        await bot.delete_message(chat_id=message.chat.id, message_id=message.message_id)
        await message.answer(f"<a href='tg://user?id={user[0]}'>{user[2]}</a> {action} <a href='tg://user?id={user2[0]}'>{user2[2]}</a>", parse_mode="html")

    else:
        match = re.search(r'@(\w+)', message.text)
        if match:
            name = match.group(1)
            if check_username(name):
                await message.reply("<b>❌ Пользователь не найден в базе данных бота!</b>")
                return
            else:
                user2 = get_username(name)
                user = get_user(message.from_user.id)
                action = message.text.lower().replace("/рп ", "").replace(".рп ", "").replace("!рп ", "").replace("!rp", "").split("@")[0]
                if action == "":
                    await message.reply("<b>❌ Укажи действие!</b>\nПример: !рп Обнял")
                await bot.delete_message(chat_id=message.chat.id, message_id=message.message_id)
                await message.answer(f"<a href='tg://user?id={user[0]}'>{user[2]}</a> {action} <a href='tg://user?id={user2[0]}'>{user2[2]}</a>", parse_mode="html")
                
        else:
            return



async def rp(message, gender, user, replyuser):
    if message.text.lower() == "обнять" and int(gender) == 1:
        await message.answer(f"🤗 | {user} обнял {replyuser}")
    else:
        await message.answer(f"🤗 | {user} обнялa {replyuser}")