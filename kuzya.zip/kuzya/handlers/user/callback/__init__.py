from .meme_call import dp
from .osnova import dp
from .funny import dp
from .moder import dp


__all__ = ['dp']