from loader import dp, bot
from aiogram import types
from aiogram.dispatcher.filters import CommandStart
from loguru import logger
from utils.db.db_utils import *



@dp.message_handler(CommandStart())
async def start(message: types.Message):
    user = message.from_user
    if check_user(user.id):
        create_user(user.id, user.username, user.first_name)
    await message.answer(f"Привет {message.from_user.first_name}, я Кузя!\n\nИспользуй  /help что-бы ознакомиться с коммандами.")