from loader import dp, bot
from keyboards.inline.help_kb import buttons
from aiogram import types



@dp.callback_query_handler(text='osnova')
async def osnova_help(call: types.CallbackQuery):
    await call.message.edit_text("<b>💡 Основные комманды</b>\n\n"
                           "<b>— Поддерживаемые префиксы</b> - <code>/</code>, <code>!</code>, <code>.</code>\n\n"
                           "● <code>/start</code> - Запуск бота\n"
                           "● <code>/help</code> - Помощь\n\n"
                           "● <code>!вики</code> (текст) - Поиск в Википедии\n"
                           "● <code>!random</code> - Рандомная статья с Википедии\n"
                           "● <code>!погода</code> (город) - Узнать погоду в городе\n"
                           "● <code>!мем</code> - Показать мемчик\n"
                           "● <code>!аниме</code> (название) - Информация об указанном аниме (пока что на английском\n)"
                           "● <code>!рекорд</code> (можно ответом на сообщение, а можно указать аргумент) - Текст в аудио\n", parse_mode="html", reply_markup=buttons)