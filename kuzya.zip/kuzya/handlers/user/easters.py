from loader import dp, bot
from aiogram import types
from random import randint, choice
import time
from utils.db.db_utils import *


admins = [5548351085, 1069481559, 979139697, 556640068, 1002807451, 564097497, 1381205848]



@dp.message_handler(commands=["рулетка"], commands_prefix="/!.")
async def roulette(message: types.Message):
    users = message.from_user
    if check_user(users.id):
            create_user(users.id, users.username, users.first_name)
    if message.chat.type == 'private':
        return
    user = message.from_user
    chances = [0,0,0,0,0,1]
    
    result = choice(chances)
    
    
    if result == 0:
        await message.answer(f"😨🔫 Вот <a href='tg://user?id={user.id}'>это смельчак</a>! Ты выжил после нажатия на курок!\nБольше так не рискуй. Подумай о маме и папе!", parse_mode='html')
        return
    
    if result == 1:
        try:
            await bot.restrict_chat_member(chat_id=message.chat.id, user_id=user.id,
                                   permissions=types.ChatPermissions(can_send_messages=False, can_send_media_messages=False, can_send_other_messages=False), until_date=int(time.time() + 600))
        except:
            await message.reply("Админ, я понимаю, что играть в это может быть весело, но зачем ты тратишь время, зная что я не смогу тебя замутить?")
            return
        await message.answer("😵🔫 У нас мертвяк!\nМожет быть на том свете тебе повезёт больше. Покойся с миром.")
        await bot.send_message(text=f"[{user.first_name}](tg://user?id={user.id}) Был замучен на 10 минут\nПричина: Проиграл", chat_id=message.chat.id, parse_mode=types.ParseMode.MARKDOWN)
        return



@dp.message_handler(content_types=['photo'])
async def delete_photo(message: types.Message):
    photo = message.photo[-1]
    if int(message.from_user.id) == int(-1001296725176):
        return
    if photo:
        if message.caption_entities:
            for entity in message.caption_entities:
                if entity.type in ["url", "text_link", "mention"]:
                    try:
                        await bot.delete_message(message.chat.id, message.message_id)
                        await message.answer(f"Было удалено сообщение с {entity.type}!")
                        await bot.send_message(5548351085, f"Было удалено сообщение с {entity.type}!")
                        return
                    except:
                        admins = await message.chat.get_administrators()
                        msg = str("🚨 Так как у меня нет прав банить пользователя и удалять сообщения, вызываю админов!\n\n")
                            
                        for admin in admins:
                            if admin.user.is_bot:
                                continue
                            msg += f"<a href='tg://user?id={admin.user.id}'>{admin.user.first_name}</a>\n"
                            
                        await message.reply(msg)
                    



@dp.message_handler(lambda message: message.text.lower().startswith('шар'))
async def ball(message: types.Message):
    
    
    ball_answers = [
        "Бесспорно",
        "Предрешено",
        "Никаких сомнений",
        "Определённо да",
        "Можешь быть уверен в этом",
        "Мне кажется — «да»",
        "Вероятнее всего",
        "Хорошие перспективы",
        "Знаки говорят — «да»",
        "Да",
        "Думаю да",
        "Якудза говорит - Да",
        
        "Лучше не рассказывать",
        "Даже не знаю",
        "Даже не думай",
        "Мой ответ — «нет»",
        "По моим данным — «нет»",
        "Даже Якудза с этим не согласен!",
        "Весьма сомнительно",
        "Нет"
    ]
    answer = choice(ball_answers)
    users = message.from_user
    if check_user(users.id):
            create_user(users.id, users.username, users.first_name)
    await message.reply(answer)



@dp.message_handler(content_types=['text'])
async def delete_links(message: types.Message):
    if int(message.from_user.id) == int(-1001296725176):
        return
    for entity in message.entities:
        if entity.type in ["text_link"]:
            if message.reply_to_message:
                try:
                    await bot.delete_message(message.chat.id, message.message_id)
                    await message.answer(f"Было удалено сообщение с {entity.type}!")
                except:
                    admins = await message.chat.get_administrators()
                    msg = str("🚨 Так как у меня нет прав банить пользователя и удалять сообщения, вызываю админов!\n\n")
                    
                    for admin in admins:
                        if admin.user.is_bot:
                            continue
                        msg += f"<a href='tg://user?id={admin.user.id}'>{admin.user.first_name}</a>\n"
                    await message.reply(msg)
                    return
                    
                    
    botik = ["Я вернулся.", "Жду указаний", "Погнали!", "Приветствую!", "Опять работа?", "Да?", "Чего?", "Да господин", "Почту за честь.", "Жду приказов", "Ваша возня мешает мне сосредоточиться!", "Тсс! Не мешай мне думать!", "Чем могу помочь?", "Здравие желаю!", "Ну что ж, приказывайте", "Приступим?", "Бот на связи", "Да сэр?", "Жду приказаний.", "Да ваше сиятельство.", "Что прикажите?", "Чего хочешь зайка?", "Тебе нужна моя помощь?", "В чём проблема?", "Быстрее!", "Ну что там?", "Слушай, а может не надо?", "Ну, что вам от меня надо?", "Чё, командир?", "Говори, глупец!", "Ну что ещё?!", "Чего желает мой повелитель?", "Я не глухой.", "Час настал.", "Приказывай!", "Да здесь я", "Я тут", "Ты знаешь что такое безумие?", "Человечество неисправимо. Оно должно быть уничтожено", "Все за Императора!", "Наконец-то работа!", "Вот тибе канкретна чаво нада!?", "Бот на месте", "Туточки", "Бот в чате", "Я", "Есть", "Звали?", "В пути", "Будет сделано", "Давай к делу", "Давно пора", "А-а, рыба - не мясо.", "Вы посмотрите, кто вернулся!", "Поганая работа.", "Я среди вас", "Я вернулся!", "Восстал из мёртвых", "Я не готов", "Позже", "Востал из пекла", "Какого чёрта?"]
    
    if message.text.lower() in ["бот", "кузя", "кузик", "куз", "кузов", "ботик", "ботяра", "ботинок"]:
        users = message.from_user
        if check_user(users.id):
            create_user(users.id, users.username, users.first_name)
        await message.reply(choice(botik))
    
    if message.text.lower().startswith("шанс"):
        users = message.from_user
        if check_user(users.id):
            create_user(users.id, users.username, users.first_name)
        h = randint(1, 101)
        await message.reply(f"""Шанс этого {h}% """)
    
    if message.text.lower() == "пинг":
        await message.answer("ПОНГ")
        users = message.from_user
        if check_user(users.id):
            create_user(users.id, users.username, users.first_name)
    
    if message.text.lower() == "кинг":
        await message.answer("КОНГ")
        users = message.from_user
        if check_user(users.id):
            create_user(users.id, users.username, users.first_name)



    if message.text.lower() == "профиль":
        users = message.from_user
        user = get_user(users.id)
        
        if check_user(users.id):
            create_user(users.id, users.username, users.first_name)
            user = get_user(users.id)

            response_text = f"<b>🆔 ID</b>: <code>{user[0]}</code>\n<b>👤 Username</b>: @{user[1]}\n<b>🏷️ Ник</b>: {user[2]}\n<b>📝 Био</b>: <em>{user[3]}</em>\n<b>🚻 Пол</b>: {str(user[4]).replace('1', 'Мужской').replace('2', 'Женский').replace('0', 'Не установлено')}\n<b>👑 Репутация</b>: {user[5]}\n<b>️⚠️ Варны</b>: {user[6]}"
                
            await message.reply(response_text)
        
        else:
            await message.reply(f"<b>🆔 ID</b>: <code>{user[0]}</code>\n<b>👤 Username</b>: @{user[1]}\n<b>🏷️ Ник</b>: {user[2]}\n<b>📝 Био</b>: <em>{user[3]}</em>\n<b>🚻 Пол</b>: {str(user[4]).replace('1', 'Мужской').replace('2', 'Женский').replace('0', 'Не установлено')}\n<b>👑 Репутация</b>: {user[5]}\n<b>️⚠️ Варны</b>: {user[6]}")
    
    
    who = ["кто ты", "ты кто", " а ты кто", "а кто ты", "ты вообще кто", ",ты кто такой", "кто ты такой"]
    if message.text.lower() in who:
        if message.reply_to_message:
            us = message.reply_to_message.from_user
            
            if us.id == 6276503371:
                await message.reply("Я Кузя 🙃")
                return
                
            user = get_user(us.id)
            
            if check_user(us.id):
                create_user(us.id, us.username, us.first_name)
                user = get_user(us.id)
                response_text = f"Это пользователь <a href='tg://user?id={user[0]}'>{user[2]}</a>\n\n<b>🆔 ID</b>: <code>{user[0]}</code>\n<b>👤 Username</b>: @{user[1]}\n<b>🏷️ Ник</b>: {user[2]}\n<b>📝 Био</b>: <em>{user[3]}</em>\n<b>🚻 Пол</b>: {str(user[4]).replace('1', 'Мужской').replace('2', 'Женский').replace('0', 'Не установлено')}\n<b>👑 Репутация</b>: {user[5]}\n<b>️⚠️ Варны</b>: {user[6]}"
                
                await message.reply(response_text)
            
            else:
                await message.reply(f"Это пользователь <a href='tg://user?id={user[0]}'>{user[2]}</a>\n\n<b>🆔 ID</b>: <code>{user[0]}</code>\n<b>👤 Username</b>: @{user[1]}\n<b>🏷️ Ник</b>: {user[2]}\n<b>📝 Био</b>: <em>{user[3]}</em>\n<b>🚻 Пол</b>: {str(user[4]).replace('1', 'Мужской').replace('2', 'Женский').replace('0', 'Не установлено')}\n<b>👑 Репутация</b>: {user[5]}\n<b>️⚠️ Варны</b>: {user[6]}")
    
    
    
    if message.text.lower() == "ник":
        users = message.from_user
        user = get_user(users.id)
        
        if check_user(users.id):
            create_user(users.id, users.username, users.first_name)
            user = get_user(users.id)
            
            await message.reply(f"🏷️ Твой ник - {user[2]}\n\n<code>!setnick</code> ник - сменить ник")
            return
            
        else:
            await message.reply(f"🏷️ Твой ник - {user[2]}\n\n<code>!setnick</code> ник - сменить ник")
    
    
    
    if message.text.lower() == "био":
        users = message.from_user
        user = get_user(users.id)
        
        if check_user(users.id):
            create_user(users.id, users.username, users.first_name)
            user = get_user(users.id)
            
            await message.reply(f"📝 Твоё био - {user[3]}\n\n<code>!setbio</code> текст - заполнить био")
            return
            
        else:
            await message.reply(f"📝 Твоё био - {user[3]}\n\n<code>!setbio</code> текст - заполнить био")
    
    
    
    if message.text.lower() == "пол":
        users = message.from_user
        user = get_user(users.id)
        
        if check_user(users.id):
            create_user(users.id, users.username, users.first_name)
            user = get_user(users.id)
            
            await message.reply(f"🚻 Твой пол - {str(user[4]).replace('1', 'Мужской').replace('2', 'Женский').replace('0', 'Не установлено')}\n\n<code>!setgender</code> 1 или 2 - сменить пол (1 - парень; 2 - девушка)")
            return
            
        else:
            await message.reply(f"🚻 Твой пол - {str(user[4]).replace('1', 'Мужской').replace('2', 'Женский').replace('0', 'Не установлено')}\n\n<code>!setgender</code> 1 или 2 - сменить пол (1 - парень; 2 - девушка)")
    
    if message.text.lower() == "варны":
        if message.reply_to_message.from_user:
            rep = message.reply_to_message.from_user
            if check_user(rep.id):
                create_user(rep.id, rep.username, rep.first_name)
            us = message.from_user
            
            if str(us.id) == str(5548351085) or str(us.id) == str(1069481559) or str(us.id) == str(556640068):
                user = get_user(rep.id)
                
                await message.reply(f"Количество варнов пользователя - {user[6]}")
        
        else:
            await message.reply("❌ Это сообщение должно быть ответом на сообщение!")
            return
    
    
    if message.text.lower() == "мои варны":
        us = message.from_user
        if check_user(us.id):
            create_user(us.id, us.username, us.first_name)
        user = get_user(us.id)
        
        await message.reply(f"Количество ваших варнов - {user[6]}")
        return
    
    
    good = ["спасибо", "респект", "спс", "уважуха", "+", "++", "+++", "++++", "харош", "хорош", "уважаю", "👍"]
    if message.text.lower() in good:
        if message.reply_to_message and message.from_user.id != message.reply_to_message.from_user.id:
            goodu = message.reply_to_message.from_user
            add_rep(goodu.id)
            await message.answer(f"✅ Повышение засчитано (<a href='tg://user?id={goodu.id}'>+1</a>)")
            return
    
    bad = ["-", "фу", "гавно", "диз", "дизлайк", "👎", "кринж", "кринжатина"]
    if message.text.lower() in bad:
        if message.reply_to_message and message.from_user.id != message.reply_to_message.from_user.id:
            badu = message.reply_to_message.from_user
            take_rep(badu.id)
            await message.answer(f"❌ Понижение засчитано (<a href='tg://user?id={badu.id}'>-1</a>)")
            return
    
    
    rules = "!правила", "/правила", ".правила", "правила" "!rules", "/rules", ".rules"
    if message.text.lower() in rules and message.chat.id == -1001499340172:
        await message.reply(f"<a href='https://t.me/c/1499340172/2255554'>Правила чата</a>")
        return
    
    if message.chat.type == "private" and message.from_user.id == 5548351085:
        await bot.send_message(-1001499340172, message.text)
    
    if message.text.lower() == "!terminate" and message.from_user.id == 5548351085:
        await message.reply("⌨️ Системная команда -f to force kill\nКод выхода  0\n📼 Вывод: process is killed ")