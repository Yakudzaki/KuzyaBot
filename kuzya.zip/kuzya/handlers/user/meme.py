from loader import dp, bot

from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

import aiohttp
from bs4 import BeautifulSoup

from random import randint, choice



async def anti_flood(*args, **kwargs):

    message = args[0]

    await message.answer("Мем читай, а не спамь сука!", show_alert=True)



@dp.message_handler(commands=["meme", "mem", "мем"], commands_prefix="/!.")

@dp.throttled(anti_flood,rate=2)

async def meme(message: types.Message):

    try:

        random_site = randint(1, 2857)

        url = f"https://www.memify.ru/memes/{random_site}"

        async with aiohttp.ClientSession() as session:

            async with session.get(url) as response:

                content = await response.text()

                soup = BeautifulSoup(content, "html.parser")

                items = soup.find_all("div", {"class": "infinite-item card"})

                random_item = choice(items)

                second_a = random_item.find_all("a")[1]

                keyboard = types.InlineKeyboardMarkup()

                buttons = [

                    types.InlineKeyboardButton(text="🔄 Обновить", callback_data="update")

                ]

                keyboard.add(*buttons)

                await bot.send_photo(message.chat.id, second_a.get("href"), caption = f'☄️ Лови мем.\n\n<a href="https://t.me/KuzyaBotNews">Канал с новостями</a>', reply_markup=keyboard, parse_mode="html")

    except Exception as e:

        print(e)