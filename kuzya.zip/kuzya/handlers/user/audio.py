from loader import dp, bot
from aiogram import types
from data.config import server_dir
import os, logging, aioschedule, asyncio,  gtts, secrets, string



@dp.message_handler(commands=["record", "рекорд"], commands_prefix="/!.")
async def handler_record(message: types.Message):
    if message.reply_to_message:
        args = message.reply_to_message.text
        
    else:
        args = message.text.replace("!record ", "").replace("/record ", "").replace(".record ", "").replace("!рекорд ", "").replace("/рекорд ", "").replace("/record@Kuzya_Robot", "")
    
    if args == "/record" or args == "!record" or args == "!рекорд" or args == "" or args == "/рекорд" or args == ".record" or args == ".рекорд":
        await message.reply("<b>❌ Укажите текст или сделайте ответ на сообщение коммандой!</b>")
        return
         
    
    await bot.delete_message(chat_id=message.chat.id, message_id=message.message_id)
    
    text = gtts.gTTS(args, lang="ru")
    alphabet = string.ascii_letters + string.digits
    name = ''.join(secrets.choice(alphabet) for i in range(16))
    text.save(server_dir + f"/voice/{name}.mp3") 
    await bot.send_voice(message.chat.id, open(server_dir + f"/voice/{name}.mp3", "rb"))

    os.remove(server_dir + f"/voice/{name}.mp3")
    
    
    
@dp.message_handler(commands=["say", "скажи"], commands_prefix="!/.")
async def say(message: types.Message):
    try:
        if message.reply_to_message:
            text = message.reply_to_message.text
        
        else:
            text = message.text.replace("!say", "").replace("/say", "").replace("!скажи", "")
            
        sos = ["!say", "/say", "!скажи"]
             
        if text in sos:
            await message.reply("<b>❌ Укажите текст, либо сделайте ответ коммандой на то сообщение которое я должен сказать!</b>\nПример: !say привет; !скажи привет")
            return
        elif len(text) > 100:
            await message.reply("<b>❌ Вы превысили ограничение на количество символов</b>!\n Максимальное количество символов - 100")
        
        await bot.delete_message(message.chat.id, message.message_id)
        await bot.send_message(message.chat.id, text)
    except:
        await message.answer("<b>❌ Укажите текст, либо сделайте ответ коммандой на то сообщение которое я должен сказать!</b>\nПример: !say привет; !скажи привет")
        return