from loader import dp, bot
from keyboards.inline.help_kb import buttons
from aiogram import types



@dp.callback_query_handler(text='moder')
async def moder_help(call: types.CallbackQuery):
    await call.message.edit_text("<b>👮 Модерация</b>\n\n"
                           "<b>— Поддерживаемые префиксы</b> - <code>/</code>, <code>!</code>, <code>.</code>\n\n"
                           "■ <code>!мут</code> время причина - Замутить юзера (Пример: !мут 10 м спам)\n"
                           "■ <code>!размут</code> - Размутить юзера\n\n"
                           "■ <code>!бан</code> причина - Забанить юзера\n"
                           "■ <code>!разбан</code> - Разбанить юзера\n"
                           "■ <code>!варн</code> - Выдать предупреждение юзеру\n"
                           "■ <code>!анварн</code> - Забрать предупреждение у юзера\n"
                           "■ <code>!админы</code> - Вызов админов\n"
                           "!Правила - Посмотреть правила"
                           "■ <code>Варны</code> - Посмотреть количество предупреждений юзера\n"
                           "■ <code>Мои варны</code> - Посмотреть количество своих предупреждений\n\n"
                           "⚠️ Все комманды использовать в ответ на сообщение!", parse_mode="html", reply_markup=buttons)