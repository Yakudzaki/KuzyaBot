from loader import dp, bot
from aiogram import types
from utils.db.db_utils import *



@dp.message_handler(commands=["setnick"], commands_prefix="!/.")
async def nick_handler(message: types.Message):
    users = message.from_user
    if check_user(users.id):
            create_user(users.id, users.username, users.first_name)
    nick = message.text.replace("!setnick ", "").replace("/setnick ", "").replace(".setnick ", "")
    raises = ["!setnick", "/setnick", ".setnick", ""]
    
    if nick in raises:
        await message.reply("<b>❌ Укажите ник!</b>")
        return
        
    elif len(nick) > 20:
        await message.reply("<b>❌ Ник не может содержать больше 20 символов!</b>")
        return
    
    elif "https://" in nick:
        await message.reply("<b>❌ Ник не может содержать ссылок!</b>")
        await bot.delete_message(chat_id=message.chat.id, message_id=message.message_id)
        
    else:
        user = message.from_user
        set_nick(user.id, nick)
        await message.reply("<b>✅ Ник успешно изменён!</b>")
        return



@dp.message_handler(commands=["setbio"], commands_prefix="!/.")
async def bio_handler(message: types.Message):
    users = message.from_user
    if check_user(users.id):
            create_user(users.id, users.username, users.first_name)
            
    bio = message.text.replace("!setbio ", "").replace("/setbio ", "").replace(".setbio ", "")
    raises = ["!setbio", "/setbio", ".setbio", ""]
    
    if bio in raises:
        await message.reply("<b>❌ Укажите текст!</b>")
        return
        
    elif len(bio) > 50:
        await message.reply("<b>❌ Био не может содержать больше 50 символов!</b>")
        return
        
    elif "https://" in bio:
        await message.reply("<b>❌ Био не может содержать ссылок!</b>")
        await bot.delete_message(chat_id=message.chat.id, message_id=message.message_id)
        return
        
    else:
        user = message.from_user
        set_bio(user.id, bio)
        await message.reply("<b>✅ Био успешно изменено!</b>")
        return



@dp.message_handler(commands=["setgender"], commands_prefix="/!.")
async def gender_handler(message: types.Message):
    if check_user(message.from_user.id):
            create_user(message.from_user.id, message.from_user.username, message.from_user.first_name)
            
    gender = message.text.replace("!setgender ", "").replace("/setgender ", "").replace(".setgender ", "")
    raises = ["!setgender", "/setgender", ".setgender", ""]
    
    if gender in raises:
        await message.reply("<b>❌ Укажите значение!</b>")
        return
    
    if int(gender) != int(1) and int(gender) != int(2):
        await message.reply("<b>❌ Укажите верное значение!</b>\nПример: !setgender 1\n1 - Парень; 2 - девушка.")
        return
    else:
        user = message.from_user
        set_gender(user.id, gender)
        await message.reply("<b> ✅ Пол успешно изменён!</b>")