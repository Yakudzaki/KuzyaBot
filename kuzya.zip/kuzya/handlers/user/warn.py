from loader import dp, bot
from aiogram import types
from utils.db.db_utils import *
import datetime



@dp.message_handler(commands=["warn", "варн"], commands_prefix="/!.", is_chat_admin=True)
async def warn_handler(message: types.Message):
    user = message.from_user
    reply = message.reply_to_message.from_user
    
    if check_user(reply.id):
        create_user(reply.id, reply.username, reply.first_name)
        res = get_user(reply.id)
        
        if int(res[6]) == int(3):
            await message.answer("⚠️ | Пользователь <a href='tg://user?id={res[0]}'>{res[2]}</a> набрал максимальное количество предупреждений, в результате чего был заблокирован!")
            return
        
        if int(res[6]) == int(2):
            add_warn(reply.id)
            
            await bot.kick_chat_member(message.chat.id, reply.id, types.ChatPermissions(False))
            await message.answer("⚠️ | Пользователь <a href='tg://user?id={res[0]}'>{res[2]}</a> получил третье предупреждение, в результате чего был заблокирован!")
            return
        
        if int(res[6]) == int(1):
            add_warn(reply.id)
            await bot.restrict_chat_member(message.chat.id, reply.id, ChatPermissions(False), until_date=datetime.timedelta(hours=2))
            await message.answer("⚠️ | Пользователь <a href='tg://user?id={res[0]}'>{res[2]}</a> получил второе предупреждение, в результате чего был замучен на 2 часа!")
            return
            
        
        await message.answer(f"⚠️ | <a href='tg://user?id={user.id}'>Администратор</a> выдал варн пользователю <a href='tg://user?id={res[0]}'>{res[2]}</a>\nВсего предупреждений {res[6]}/3")
        return
        
    else:
        add_warn(reply.id)
        res = get_user(reply.id)
        await message.answer(f"⚠️ | <a href='tg://user?id={user.id}'>Администратор</a> выдал варн пользователю <a href='tg://user?id={res[0]}'>{res[2]}</a>\nВсего предупреждений ({res[6]}/3)")
        return



@dp.message_handler(commands=["unwarn", "анварн"], commands_prefix="/!.", is_chat_admin=True)
async def unwarn_handler(message: types.Message):
    user = message.from_user
    reply = message.reply_to_message.from_user
    
    if check_user(reply.id):
        create_user(reply.id, reply.first_name, reply.username)
        res = get_user(reply.id)
        
        if int(res[6]) == int(0):
            await message.answer("❌ У Пользователя <a href='tg://user?id={res[0]}'>{res[2]}</a> нет предупреждений!")
            return
        take_warn(reply.id)
        
        await message.answer(f"⚠️ | <a href='tg://user?id={user.id}'>Администратор</a> забрал варн у пользователя <a href='tg://user?id={res[0]}'>{res[2]}</a>\nВсего предупреждений ({res[6]}/3)")
        return
        
    else:
        take_warn(reply.id)
        res = get_user(reply.id)
        await message.answer(f"⚠️ | <a href='tg://user?id={user.id}'>Администратор</a> забрал варн у пользователя <a href='tg://user?id={res[0]}'>{res[2]}</a>\nВсего предупреждений ({res[6]}/3)")
        return